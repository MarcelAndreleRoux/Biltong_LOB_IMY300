Known bugs:

- Trajectory line is offset from the player in all levels except for level 1.
- The turtle's animations are a bit buggy and it sticks to the player when the player touches it.
- The lizard needs an electrical arc that connects to the wireless components and player.
- The hedgehog's animations also need some refining. 

