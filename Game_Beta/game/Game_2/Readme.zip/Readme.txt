Controls:

W - Up
A - Left
S - Down
D - Right
E - Pickup
Q - Drop
Left click - Throw left
Right click - Throw Right
Space - Climb

Items:

Rock 
Fire Mango
Roofie Shroom
