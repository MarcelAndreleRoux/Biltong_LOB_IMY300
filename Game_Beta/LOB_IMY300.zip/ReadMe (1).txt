Known bugs:

- The inventory is a bit buggy but works most of the time. the key     binds for it are 1, 2 and 3 respectively.
- The turtle eats other throwables which should not be the case. It should only eat mushrooms. We are working on fixing it.